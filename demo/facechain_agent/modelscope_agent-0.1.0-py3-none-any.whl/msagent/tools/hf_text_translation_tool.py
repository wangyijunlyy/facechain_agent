from transformers.tools import TranslationTool

from .tool import Tool


class HFTextTranslationTool(Tool):
    description = 'This is a tool that translates text from a language to another.'
    name = 'hf_text_translation'
    parameters: list = [{
        'name': 'text',
        'description': 'input tool',
        'required': True
    }, {
        'name': 'src_lang',
        'description':
        "the language of the text to translate, this parameters \
            are written in plain English, such as 'Romanian', or 'Albanian'",
        'required': True
    }, {
        'name': 'tgt_lang',
        'description':
        "the language for the desired output language, this parameters \
            are written in plain English, such as 'Romanian', or 'Albanian'",
        'required': True
    }]

    def __init__(self):
        self.tool = TranslationTool()
        super().__init__()

    def _local_call(self, *args, **kwargs):
        return {'result': self.tool(kwargs)}
