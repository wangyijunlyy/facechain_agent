import cv2

from .pipeline_tool import ModelscopePipelineTool, Tasks


class TextToImageTool(ModelscopePipelineTool):
    default_model = 'AI-ModelScope/stable-diffusion-v2-1'
    description = '图像生成服务，针对文本输入，生成对应的图片'
    name = 'modelscope_image-generation'
    url: str = 'http://33.57.174.141:5000/modelscope_image-generation'
    parameters: list = [{
        'name': 'text',
        'description': '用户输入的文本信息',
        'required': True
    }]
    model_revision = 'v1.0.0'
    task = Tasks.text_to_image_synthesis

    def _remote_parse_input(self, *args, **kwargs):
        return {'url': self.url, 'parameters': kwargs}

    def _local_call(self, text: str):
        self.setup()
        img = cv2.cvtColor(
            self.pipeline({'text': text})['output_imgs'][0], cv2.COLOR_BGR2RGB)
        return {'result': ImageWrapper(img)}
